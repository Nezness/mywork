import boto3 # AWS tool-kit SDK
import json # Data to json
import urllib.parse # fix some strange url
from datetime import datetime

s3 = boto3.client('s3')
textract = boto3.client('textract', region_name = 'us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='ap-northeast-1')

TABLE_NAME = 'Receipts'
table = dynamodb.Table(TABLE_NAME)

receipt_data = {
            "vendor_name": "不明",
            "date": "不明",
            "total": "不明"
        }

def handler(event, context): # Get bucket-name and file-name from s3-bucket
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])

    # ─── S3キーの解析 ───
    # キー構造: users/{user_id}/receipts/{receipt_id}.{拡張子}
    # 例:       users/abc-123/receipts/receipt-20260131-001.jpg
    try:
        key_parts = key.split('/')
        # key_parts = ['users', 'abc-123', 'receipts', 'receipt-20260131-001.jpg']
        user_id = key_parts[1]
        # 拡張子を除去(jpg, jpeg, png に対応)
        filename = key_parts[3]
        receipt_id = filename.rsplit('.', 1)[0]  # 最後の「.」で分割して拡張子除去
    except (IndexError, ValueError):
        print(f"Error: S3キーの構造が想定と異なります: {key}")
        raise

    try: # Analyze receipt in with Textract
        s3_object = s3.get_object(Bucket=bucket, Key=key)
        image_content = s3_object['Body'].read()

        # 3. S3Object ではなく 「Bytes」 を渡す
        response = textract.analyze_expense(
            Document={
                'Bytes': image_content
            }
        )

        # Export result from analyze
        for expense_doc in response['ExpenseDocuments']:
            # SummaryFields には店名、日付、合計などが含まれる
            for field in expense_doc['SummaryFields']:
                field_type = field['Type']['Text']
                field_value = field['ValueDetection']['Text']
                        
                if field_type == 'VENDOR_NAME':
                    receipt_data["vendor_name"] = field_value
                elif field_type == 'DATE':
                    receipt_data["date"] = field_value
                elif field_type == 'TOTAL':
                    receipt_data["total"] = field_value

        print(f"Result")
        print(f"Total: {receipt_data['total']}")

        save_to_dynamodb(user_id, receipt_id, receipt_data, key)

        return{
            'StatusCode': 200,
            'body': json.dumps('Analysis successful')
        }
    
    except Exception as e:
        print(f"Error:{str(e)}")
        raise e
    
def save_to_dynamodb(user_id, receipt_id, receipt_data, s3_key):
    try:
        item = {
            'user_id': user_id,
            'receipt_id': receipt_id,
            'vendor_name': receipt_data['vendor_name'],
            'date': receipt_data['date'],
            'total': receipt_data['total'],
            's3_key': s3_key,
            'created_at': datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        }

        table.put_item(Item=item)
        print(f"DynamoDB書き込み成功: user_id={user_id}, receipt_id={receipt_id}")

    except Exception as e:
        print(f"DynamoDB書き込みエラー: {str(e)}")
        raise e